#ifndef __LEDR_CONFIG_H
#define __LEDR_CONFIG_H

/* no configuration supported yet */

#endif /* __LEDR_CONFIG_H */
