#ifndef __LEDG_CONFIG_H
#define __LEDG_CONFIG_H

/* no configuration supported yet */

#endif /* __LEDG_CONFIG_H */
