/**
 * \file
 * \brief Configuration header file for GenericI2C
 *
 * This header file is used to configure settings of the Generic I2C module.
 */

#ifndef __GI2C1_CONFIG_H
#define __GI2C1_CONFIG_H


#endif /* __GI2C1_CONFIG_H */
