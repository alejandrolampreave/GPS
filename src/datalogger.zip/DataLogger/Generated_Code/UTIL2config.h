#ifndef __UTIL2_CONFIG_H
#define __UTIL2_CONFIG_H

/* no configuration supported yet */

#endif /* __UTIL2_CONFIG_H */
